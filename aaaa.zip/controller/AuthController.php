<?php

class AuthController extends Controller
{
   public function login()
   {
      // TODO: 
   }

   public function register()
   {
      // TODO:
   }
}
