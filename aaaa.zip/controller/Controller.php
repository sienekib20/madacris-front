<?php
// core/Controller.php
class Controller extends BaseController
{
}
