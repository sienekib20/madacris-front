<?php


require_once __DIR__ . '/controller/BaseController.php';
require_once __DIR__ . '/../controller/Controller.php';
require_once __DIR__ . '/map.php';
require_once __DIR__ . '/function.php';
require_once __DIR__ . '/database/DB.php';
