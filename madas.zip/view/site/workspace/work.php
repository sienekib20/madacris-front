<style>
   .section-card-title {
      font-family: 'Onest-Bold';
      font-size: 1.2rem;
   }

   @media (max-width: 992px) {
      .row-to-reverse {
         flex-direction: column-reverse !important;
      }
   }
</style>
<?= view_component("include") ?>
<div class="wrapper">

   <?= view_component('nav.topnav') ?>

   <div class="section-card">
      <div class="section-card-container">
         <div class="main-container px-4 px-sm-5">
            <div class="row">
               <div class="col-lg-6 col-12">
                  <span class="section-card-title block">Workspace</span>
               </div>
            </div>
         </div>
      </div>
   </div>

   <div class="section-card pt-3 pb-5">
      <div class="section-card-contain">
         <div class="main-container px-4 px-sm-5">
            <div class="row">
               <div class="col-lg-3">
                  <aside class="sidepane">
                     <ul class="items">
                        <li>
                           <a href="">Minha conta</a>
                        </li>
                        <li>
                           <a href="">Meus Pedidos</a>
                        </li>
                        <li>
                           <a href="">Comentarios</a>
                        </li>
                     </ul>
                  </aside>
               </div>
               <div class="col-lg-9">
                  <div class="tabs">
                     <div class="tab-item active">
                        <!-- Minha Conta -->
                     </div>
                     <div class="tab-item active">
                        <div class="col-12">
                           <div class="cart-products mt-5n">
                              <div class="flex items-center cart-top-table" style="border-bottom: 1px solid rgba(0, 0, 0, 0.15); padding-bottom: 0.5rem; margin-top: -0.5rem !important">
                                 <span class="cart-product-title pb-4 adapate-font-size">Pediso feitos</span>
                                 <a href="#" class="ml-auto text-black text-underline btn-update-total" name="" role="button">
                                    <small>Limpar lista</small>
                                 </a>
                              </div>

                              <div class="container-products">
                                 <div class="cart-products-list w-100" id="">
                                    <div class="cart-product-list-item" style="min-width: 100%">
                                       <div class="contain-img" style="min-width: 10%">
                                          <img src="<?= asset('img/2.jpg') ?>" alt="">
                                       </div>
                                       <div class="cart-product-name ml-4" style="min-width: 280px">
                                          <span class="name adapate-font-size">Nome</span>
                                          <small class="text-black d-block">AA</small>
                                       </div>
                                       <span class="cart-product-price adapate-font-size d-flex w-15" style="min-width: 140px">AO 10 000</span>
                                       <input type="number" id="artigo-item-${index}" class="default-input w-10 text-center" value="1" min="1" style="min-width: 80px" />

                                       <span class="cart-product-price adapate-font-size jc-end d-flex w-15 mr-3" id="cartProductPrice" style="min-width: 200px">
                                          Status: Pendente
                                       </span>
                                       <a href="" class="cart-product-action d-flex w-20">
                                          <!-- <i class="bx bxs-trash-alt adapate-font-size"></i> -->
                                          
                                       </a>
                                       <ar href="" class="cart-product-action text-underline d-flex w-20">
                                          ver
                                          <!-- <i class="bx bxs-show adapate-font-size"></i> -->
                                          <!-- Mostrar Lista em forma de PDF (RECIBO DO CLIENTE - A CARREGAR DO BACK) -->
                                       </a>
                                       <a href="" class="cart-product-action d-flex w-20">
                                          <i class="bx bxs-edit adapate-font-size"></i>
                                       </a>

                                    </div>
                                 </div>
                              </div>

                           </div>
                        </div>
                     </div>
                     <div class="tab-item">
                        <!-- Comentarios -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>


   <span class="flex mt-4"></span>


   <?= view_component('footer') ?>
</div>

<script>
   // Change Tabs
</script>