<div class="styled-alert">
   <a href="" class="std-alert-close">
      <i class="bx bx-x"></i>
   </a>
   <span class="std-alert-text"></span>
</div>