<script src="<?= asset('js/styled-alerts.js') ?>"></script>
<script src="<?= asset('js/storage/cart.js') ?>"></script>
