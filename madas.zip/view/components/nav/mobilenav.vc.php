<ul class="mobile-m px-2 px-sm-4" role="navigation">
   <li class="mm-item">
      <a href="" class="mm-link">Inicio</a>
   </li>
   <li class="mm-item">
      <a href="" class="mm-link">Todos os artigos</a>
   </li>
   <li class="mm-item">
      <a href="" class="mm-link">Vestidos</a>
   </li>
   <li class="mm-item">
      <a href="" class="mm-link">Joias</a>
   </li>
   <li class="mm-item">
      <a href="" class="mm-link">Sobre</a>
   </li>
   <li class="mm-item">
      <a href="" class="mm-link">Contactos</a>
   </li>
   <li class="mm-item">
      <a href="" class="mm-link">Termos de uso</a>
   </li>
</ul>