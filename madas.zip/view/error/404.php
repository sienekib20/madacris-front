<?php $this->extends('auth', ['title' => 'Not Found']) ?>

<div class="not-found">


    <span>404 | NOT FOUND</span>

    <small><?= $message ?></small>

</div>