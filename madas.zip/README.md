# Piloto-Office

## Para manipular sessoes chama o metodo: session()-> e teras todos os metodos