<?php

class WorkspaceController extends Controller
{
   public function index()
   {
      // TODO: 
      return view('site.workspace.work');
   }

}
